package com.example.ch4labs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch4LabsApplicationTests {

    @Test
    void contextLoads() {
    }

}
