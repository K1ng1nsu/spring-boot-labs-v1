package com.example.ch4labs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch4LabsApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ch4LabsApplication.class, args);
    }

}
