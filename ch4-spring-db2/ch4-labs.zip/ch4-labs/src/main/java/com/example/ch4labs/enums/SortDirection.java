package com.example.ch4labs.enums;

public enum SortDirection {
    ASC,
    DESC;
}
