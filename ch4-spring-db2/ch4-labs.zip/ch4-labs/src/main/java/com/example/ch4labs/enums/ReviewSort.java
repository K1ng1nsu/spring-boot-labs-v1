package com.example.ch4labs.enums;

public enum ReviewSort {
    CREATED,
    TITLE,
    CONTENT,
    AUTHOR,
    BOOK_TITLE,
    BOOK_AUTHOR,
    RATING,
    ;
}
